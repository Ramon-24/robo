import cv2
import pyautogui
import time 
from cvzone.HandTrackingModule import HandDetector

pyautogui.PAUSE = 1.2

# Configuração do detector de mãos
detector = HandDetector(detectionCon=0.8, maxHands=1)

# Captura de vídeo
video = cv2.VideoCapture(0)

while True:
    ret, frame = video.read()
    frame = cv2.flip(frame, 1)  # Espelha a imagem
    hands, img = detector.findHands(frame)

    # Verifica se há mãos detectadas
    if hands:
        lmList = hands[0]
        fingerUp = detector.fingersUp(lmList)

        print(fingerUp)
        
        # Exibe o número de dedos levantados na tela
        if fingerUp == [0, 1, 1, 1, 0]:
            cv2.putText(frame, 'Finger count: 0', (20, 460), cv2.FONT_HERSHEY_COMPLEX, 1, (200, 255, 255), 1, cv2.LINE_AA)
            pyautogui.press('win')
            pyautogui.click(x=263, y=88)
            pyautogui.write('opera')
            pyautogui.press('enter')
            pyautogui.write('https://www.tinkercad.com/dashboard')
            pyautogui.press('enter')

        elif fingerUp == [0, 1, 0, 0, 0]:
            cv2.putText(frame, 'Finger count: 1', (20, 460), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1, cv2.LINE_AA)
            pyautogui.press('win')
            pyautogui.click(x=263, y=88)
            pyautogui.write('opera')
            time.sleep(6)
            pyautogui.press('enter')
            pyautogui.write('https://www.engenhariahibrida.com.br/post/robotica-o-que-e-historico-tipos-aplicacoes#viewer-foo')
            pyautogui.press('enter')
            time.sleep(5)
            pyautogui.moveTo(x=382, y=300)
            pyautogui.scroll(+150)
        elif fingerUp == [0, 1, 1, 0, 0]:
            cv2.putText(frame, 'Finger count: 2', (20, 460), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1, cv2.LINE_AA)
            pyautogui.press('win')
            pyautogui.click(x=263, y=88)
            pyautogui.write('opera')
            time.sleep(6)
            pyautogui.press('enter')
            pyautogui.write('https://www.activecampaign.com/br/glossary/o-que-significa-automacao')
            pyautogui.press('enter')
            time.sleep(5)
            pyautogui.moveTo(x=382, y=300)
            pyautogui.scroll(-150)
        elif fingerUp == [0, 0, 0, 0, 0]:
            cv2.putText(frame, 'Finger count: 3', (20, 460), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1, cv2.LINE_AA)
        elif fingerUp == [0, 1, 1, 1, 1]:
            cv2.putText(frame, 'Finger count: 4', (20, 460), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1, cv2.LINE_AA)
        elif fingerUp == [1, 1, 1, 1, 1]:
            cv2.putText(frame, 'Finger count: 5', (20, 460), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1, cv2.LINE_AA) 

    # Exibe o frame com o texto
    cv2.imshow("Sensor jorge automatico", frame)

    # Pressione 'key' para sair
    key = cv2.waitKey(1)
    if key == 27:
        break
 

# Libera a captura de vídeo e fecha as janelas
video.release()
cv2.destroyAllWindows()
