import pyautogui
import time

pyautogui.PAUSE = 0.5

pyautogui.press('win')
pyautogui.click(x=263, y=88)
pyautogui.write('opera')
time.sleep(2)
pyautogui.press('enter')
pyautogui.write('https://www.activecampaign.com/br/glossary/o-que-significa-automacao')
pyautogui.press('enter')
time.sleep(4)
pyautogui.moveTo(x=382, y=300)
pyautogui.scroll(-150)
